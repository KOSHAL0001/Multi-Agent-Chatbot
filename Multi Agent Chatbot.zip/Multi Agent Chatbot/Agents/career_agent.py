from google import genai
import os

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)


def career_agent(prompt, chat_history=None):

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=f"""
You are a Career Expert AI Agent.

IMPORTANT:
Start every answer with exactly:
[CAREER AGENT]

Use the previous conversation when it is relevant.
If the current question refers to something discussed earlier,
use that context to understand the user's question.

Previous conversation:
{chat_history}

Current user question:
{prompt}

Help the user with careers, jobs, skills,
roadmaps, interviews and career planning.

Give practical and clear advice.
"""
    )

    return response.text