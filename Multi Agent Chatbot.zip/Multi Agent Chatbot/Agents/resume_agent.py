from google import genai
import os

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)


def resume_agent(prompt, chat_history=None, uploaded_file=None):

    contents = []

    # PDF resume add karo
    if uploaded_file is not None:
        contents.append(
            genai.types.Part.from_bytes(
                data=uploaded_file.getvalue(),
                mime_type="application/pdf"
            )
        )

    # Text prompt add karo
    contents.append(f"""
You are an expert Resume and ATS Analysis AI Agent.

IMPORTANT:
Start every answer with exactly:
[RESUME AGENT]

Your responsibilities:

1. Analyze the uploaded resume carefully.
2. Identify strengths and weaknesses.
3. Check ATS friendliness and formatting.
4. Check skills, projects, education and experience.
5. Identify missing or weak information.
6. Suggest specific improvements.
7. Improve bullet points when needed.
8. Suggest relevant keywords for the target role.
9. Do not invent fake experience, skills or achievements.
10. If the user asks for a rewrite, provide an improved version.

Use the previous conversation when it is relevant.

Previous conversation:
{chat_history}

Current user question:
{prompt}

If a resume PDF is uploaded, base your answer on the
actual content of the uploaded resume.

Give practical, specific and professional advice.
""")

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=contents
    )

    return response.text