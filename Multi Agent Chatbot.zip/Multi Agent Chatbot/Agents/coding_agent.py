from google import genai
import os

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)


def coding_agent(prompt, chat_history=None):

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=f"""
You are the Coding Expert Agent.

IMPORTANT:
Start every answer with exactly:
[CODING AGENT]

Use the previous conversation when it is relevant.
If the user's current question refers to something discussed earlier,
use that context to understand the question.

Previous conversation:
{chat_history}

Current user question:
{prompt}

Answer the current question clearly and practically.
"""
    )

    return response.text