# from google import genai
# import os

# client = genai.Client(
#     api_key=os.getenv("GEMINI_API_KEY")
# )


# def router_agent(prompt):

#     response = client.models.generate_content(
#         model="gemini-3.6-flash",
#         contents=f"""
# You are an intelligent routing agent for a multi-agent chatbot.

# Your job is to analyze the user's question and decide which
# specialized agent should handle it.

# Available agents:

# 1. CODING
#    Use for programming, coding, software development, debugging,
#    programming languages, algorithms, DSA, APIs, databases,
#    frameworks, technical concepts, or code-related questions.

# 2. CAREER
#    Use for career planning, job preparation, internships,
#    career paths, skills to learn, interview preparation,
#    job decisions, or professional growth.

# 3. RESUME
#    Use for resumes, CVs, cover letters, ATS optimization,
#    resume improvement, resume summaries, resume projects,
#    resume skills, or anything specifically related to improving
#    a job application document.

# 4. GENERAL
#    Use when the question does not clearly belong to Coding,
#    Career, or Resume.

# IMPORTANT RULES:
# - Understand the meaning and intent of the complete question.
# - Do NOT classify based only on individual keywords.
# - Consider the user's main goal.
# - If multiple categories appear, choose the category that is
#   the PRIMARY purpose of the user's request.
# - Return ONLY ONE of these exact words:
#   coding
#   career
#   resume
#   general

# Examples:

# User: "Explain pointers in C++"
# Output: coding

# User: "How do I debug this Python error?"
# Output: coding

# User: "Should I learn Python or Java for software development?"
# Output: coding

# User: "How can I prepare for an AI Engineer interview?"
# Output: career

# User: "What skills should I learn to become an AI Engineer?"
# Output: career

# User: "How can I improve my resume for an AI Engineer job?"
# Output: resume

# User: "Add my Python project to my CV"
# Output: resume

# User: "What should I write in my resume summary?"
# Output: resume

# User: "What is the capital of France?"
# Output: general

# User's question:
# {prompt}

# Return ONLY the category name.
# """
#     )

#     return response.text.strip().lower()
from google import genai
import os

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)


def router_agent(prompt, chat_history=None):

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=f"""
You are an intelligent routing agent for a multi-agent chatbot.

Your job is to analyze the user's question and decide which
specialized agent should handle it.

Available agents:

1. CODING
   Use for programming, coding, software development, debugging,
   programming languages, algorithms, DSA, APIs, databases,
   frameworks, technical concepts, or code-related questions.

2. CAREER
   Use for career planning, job preparation, internships,
   career paths, skills to learn, interview preparation,
   job decisions, or professional growth.

3. RESUME
   Use for resumes, CVs, cover letters, ATS optimization,
   resume improvement, resume summaries, resume projects,
   resume skills, or anything specifically related to improving
   a job application document.

4. GENERAL
   Use when the question does not clearly belong to Coding, Career, or Resume.

IMPORTANT RULES:
- Understand the meaning and intent of the complete question.
- Do NOT classify based only on individual keywords.
- Consider the user's main goal.
- If multiple categories appear, choose the category that is
  the PRIMARY purpose of the user's request.
- Use the previous conversation when the current question
  depends on earlier context.
- Return ONLY ONE of these exact words:
  coding
  career
  resume
  general

Examples:

User: "Explain pointers in C++"
Output: coding

User: "How do I debug this Python error?"
Output: coding

User: "Should I learn Python or Java for software development?"
Output: coding

User: "How can I prepare for an AI Engineer interview?"
Output: career

User: "What skills should I learn to become an AI Engineer?"
Output: career

User: "How can I improve my resume for an AI Engineer job?"
Output: resume

User: "Add my Python project to my CV"
Output: resume

User: "What should I write in my resume summary?"
Output: resume

User: "What is the capital of France?"
Output: general

Previous conversation:
{chat_history}

Current user question:
{prompt}

Return ONLY the category name.
"""
    )

    return response.text.strip().lower()