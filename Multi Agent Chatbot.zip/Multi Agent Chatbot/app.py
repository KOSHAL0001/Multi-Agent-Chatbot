from dotenv import load_dotenv
import os

load_dotenv()

from google import genai
import streamlit as st


from Agents.router_agent import router_agent
from Agents.coding_agent import coding_agent
from Agents.career_agent import career_agent
from Agents.resume_agent import resume_agent


# =========================================================
# PAGE CONFIG
# =========================================================

st.set_page_config(
    page_title="Multi-Agent AI",
    page_icon="🤖",
    layout="wide"
)


# =========================================================
# GEMINI API
# =========================================================

api_key = os.getenv("GEMINI_API_KEY")

client = genai.Client(
    api_key=api_key
)


# =========================================================
# CUSTOM CSS
# =========================================================

st.markdown("""
<style>

    /* =========================
       MAIN BACKGROUND
    ========================== */

    .stApp {
        background: linear-gradient(
            135deg,
            #080b16 0%,
            #111827 50%,
            #0b1020 100%
        );
        color: #f8fafc;
    }


    /* =========================
       MAIN CONTENT
    ========================== */

    .block-container {
        max-width: 1050px;
        padding-top: 2rem;
        padding-bottom: 6rem;
    }


    /* =========================
       HEADER
    ========================== */

    .main-title {
        text-align: center;
        font-size: 48px;
        font-weight: 800;
        margin-bottom: 5px;

        background: linear-gradient(
            90deg,
            #a78bfa,
            #6366f1,
            #22d3ee
        );

        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }


    .subtitle {
        text-align: center;
        color: #94a3b8;
        font-size: 17px;
        margin-bottom: 35px;
    }


    /* =========================
       SIDEBAR
    ========================== */

    [data-testid="stSidebar"] {
        background: linear-gradient(
            180deg,
            #070a12,
            #111827
        );

        border-right: 1px solid #1e293b;
    }


    [data-testid="stSidebar"] h2 {
        color: #c4b5fd;
    }


    [data-testid="stSidebar"] h3 {
        color: #a5b4fc;
    }


    /* =========================
       RESUME UPLOAD
    ========================== */

    [data-testid="stFileUploader"] {
        background: rgba(30, 41, 59, 0.65);
        border: 1px solid #475569;
        border-radius: 18px;
        padding: 18px;

        box-shadow:
            0 10px 30px rgba(0, 0, 0, 0.25);
    }


    [data-testid="stFileUploader"] label {
        color: #c4b5fd;
        font-weight: 600;
    }

    [data-testid="stFileUploader"] button {
    background: #7c3aed !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    font-weight: 600 !important;
}

[data-testid="stFileUploader"] button:hover {
    background: #6d28d9 !important;
}


    /* =========================
       CHAT MESSAGES
    ========================== */

   [data-testid="stChatMessage"] { 
    border-radius: 18px; 
    margin-bottom: 14px; 
    padding: 12px; 

    background: white !important;

    border: 1px solid #e2e8f0;

    color: #111827 !important;
}

    [data-testid="stChatMessage"] p,
[data-testid="stChatMessage"] span {
    color: #111827 !important;
}


    /* =========================
       CHAT INPUT
    ========================== */

    [data-testid="stChatInput"] {
        border-radius: 18px;
    }

    [data-testid="stChatInput"] textarea {
    color: #111827 !important;
    background: #f1f5f9 !important;
}

[data-testid="stChatInput"] textarea::placeholder {
    color: #64748b !important;
}


    /* =========================
       SUCCESS MESSAGE
    ========================== */

    [data-testid="stAlert"] {
        border-radius: 12px;
    }


    /* =========================
       BUTTONS
    ========================== */

    .stButton > button {
        width: 100%;

        background: linear-gradient(
            90deg,
            #7c3aed,
            #2563eb
        );

        color: white;

        border: none;
        border-radius: 12px;

        padding: 10px 18px;

        font-weight: 600;

        transition: 0.3s;
    }


    .stButton > button:hover {
        transform: translateY(-2px);

        box-shadow:
            0 8px 20px rgba(
                99,
                102,
                241,
                0.35
            );
    }


    /* =========================
       SCROLLBAR
    ========================== */

    ::-webkit-scrollbar {
        width: 8px;
    }


    ::-webkit-scrollbar-track {
        background: #080b16;
    }


    ::-webkit-scrollbar-thumb {
        background: #475569;
        border-radius: 10px;
    }

</style>
""", unsafe_allow_html=True)


# =========================================================
# HEADER
# =========================================================

st.markdown(
    '<div class="main-title">🤖 Multi-Agent AI</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'Your intelligent assistant for Coding, Career & Resume'
    '</div>',
    unsafe_allow_html=True
)


# =========================================================
# SIDEBAR
# =========================================================

with st.sidebar:

    st.markdown("## 🤖 AI Assistant")

    st.markdown("---")

    st.markdown("### 🧠 Available Agents")

    st.markdown("""
**💻 Coding Agent**

Programming, DSA, APIs, debugging
and technical concepts.

**🎯 Career Agent**

Jobs, internships, interviews
and career roadmaps.

**📄 Resume Agent**

Resume improvement, ATS optimization
and PDF analysis.
""")

    st.markdown("---")

    st.markdown("### 💡 Try asking")

    st.caption("💻 Explain Python decorators")

    st.caption("🎯 How can I become an AI Engineer?")

    st.caption("📄 Improve my resume for an AI job")

    st.markdown("---")

    st.caption("⚡ Powered by Gemini")


# =========================================================
# RESUME UPLOAD
# =========================================================

st.markdown("### 📄 Resume Analysis")

uploaded_file = st.file_uploader(
    "Upload your resume (PDF)",
    type=["pdf"],
    help=(
        "Upload your resume to get "
        "AI-powered analysis and ATS suggestions."
    )
)


if uploaded_file is not None:

    st.success(
        f"✅ {uploaded_file.name} uploaded successfully!"
    )


# =========================================================
# CHAT MEMORY
# =========================================================

if "messages" not in st.session_state:

    st.session_state.messages = []


# =========================================================
# DISPLAY CHAT HISTORY
# =========================================================

for message in st.session_state.messages:

    with st.chat_message(message["role"]):

        st.write(message["content"])


# =========================================================
# USER INPUT
# =========================================================

prompt = st.chat_input(
    "Ask anything about coding, career or your resume..."
)


# =========================================================
# PROCESS USER REQUEST
# =========================================================

if prompt:

    # Save user message
    st.session_state.messages.append({
        "role": "user",
        "content": prompt
    })


    # Display user message
    with st.chat_message("user"):

        st.write(prompt)


    # Previous conversation
    chat_history = st.session_state.messages[:-1]


    # =====================================================
    # AGENT PROCESSING
    # =====================================================

    try:

        with st.spinner("🤖 AI Agent is thinking..."):

            # PDF uploaded → Resume Agent directly
            if uploaded_file is not None:

                agent = "resume"

            else:

                # Router decides which agent
                agent = router_agent(
                    prompt,
                    chat_history
                )


            # =================================================
            # CODING AGENT
            # =================================================

            if agent == "coding":

                answer = coding_agent(
                    prompt,
                    chat_history
                )


            # =================================================
            # CAREER AGENT
            # =================================================

            elif agent == "career":

                answer = career_agent(
                    prompt,
                    chat_history
                )


            # =================================================
            # RESUME AGENT
            # =================================================

            elif agent == "resume":

                answer = resume_agent(
                    prompt,
                    chat_history,
                    uploaded_file
                )


            # =================================================
            # UNKNOWN AGENT
            # =================================================

            else:

                answer = (
                    "Sorry, I don't know which agent "
                    "should handle this request."
                )


    # =====================================================
    # ERROR HANDLING
    # =====================================================

    except Exception as e:

        answer = (
            "⚠️ Something went wrong while processing "
            "your request.\n\n"
            f"**Error:** {e}"
        )


    # =====================================================
    # SAVE ASSISTANT RESPONSE
    # =====================================================

    st.session_state.messages.append({
        "role": "assistant",
        "content": answer
    })


    # =====================================================
    # DISPLAY ASSISTANT RESPONSE
    # =====================================================

    with st.chat_message("assistant"):

        st.write(answer)